# Order Lookup by Date Range Strategy

## Overview
Implement a feature to search and filter orders by date range, allowing users to find orders within specific time periods.

## Current State
- Orders have an `order_date` field (DateField)
- The current search functionality only allows filtering by order ID range
- Orders are displayed in a table view with HTMX for dynamic updates

## Implementation Strategy

### 1. Backend Updates
1. Modify the `order_search` view in `core/views/order.py` to accept date range parameters:
   - Add `start_date` and `end_date` parameters
   - Implement filter logic using Django ORM's date filters
   - Update the existing query to include date range filtering

### 2. Frontend Updates
1. Extend the search form in `templates/order/orders.html` to include date inputs:
   - Add date picker fields for start and end dates
   - Maintain existing ID range filter functionality
   - Use the same HTMX pattern for dynamic updates

### 3. UI/UX Considerations
1. Use HTML date inputs with appropriate validation
2. Add clear visual feedback for applied date filters
3. Ensure the reset button clears date filters as well
4. Implement proper error handling for invalid date ranges

### 4. Testing
1. Test with various date ranges:
   - Orders within specific months/quarters/years
   - Orders on specific dates
   - Empty date ranges (one or both fields empty)
   - Invalid date ranges (end date before start date)

### 5. Documentation
1. Update user documentation to explain the new date range filter feature
2. Include examples of common date range queries

## Implementation Example
```python
# View update in core/views/order.py
def order_search(request):
    min_id = request.GET.get('min_id', '')
    max_id = request.GET.get('max_id', '')
    start_date = request.GET.get('start_date', '')
    end_date = request.GET.get('end_date', '')
    
    # Start with all orders
    orders_query = Order.confirmed.all().select_related('customer')
    
    # Apply ID filters if provided
    if min_id and min_id.isdigit():
        orders_query = orders_query.filter(id__gte=int(min_id))
    
    if max_id and max_id.isdigit():
        orders_query = orders_query.filter(id__lte=int(max_id))
    
    # Apply date filters if provided
    if start_date:
        orders_query = orders_query.filter(order_date__gte=start_date)
    
    if end_date:
        orders_query = orders_query.filter(order_date__lte=end_date)
    
    # Order by descending order date (newest first)
    all_orders = orders_query.order_by('-order_date')
    
    return render(request, 'order/partials/order_rows.html', {
        'orders': all_orders
    })
```
