"""
Template tags for the Doors and Drawers application.
""" 