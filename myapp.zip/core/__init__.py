"""
Core application module for DoorsAndDrawers.
"""

# Import services module to make it available through core package
import core.services
