"""
Services module for business logic.
""" 